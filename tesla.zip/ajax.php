<?php
ini_set('display_erros', 'on');
ini_set('memory_limit', '512M');
ini_set('upload_max_filesize', '256M');
ini_set('post_max_size', '256M');
date_default_timezone_set('America/Sao_Paulo');
switch ($_REQUEST['acao']) {
    case "enviarContato":
        $_REQUEST['nome'] = (isset($_REQUEST['nome'])) ? $_REQUEST['nome'] : $_REQUEST['nomeContato'];
        $_REQUEST['email'] = (isset($_REQUEST['email'])) ? $_REQUEST['email'] : $_REQUEST['emailContato'];
        $_REQUEST['telefone'] = (isset($_REQUEST['telefone'])) ? $_REQUEST['telefone'] : $_REQUEST['telefoneContato'];
        $_REQUEST['mensagem'] = (isset($_REQUEST['mensagem'])) ? $_REQUEST['mensagem'] : $_REQUEST['mensagemContato'];
        $email['nome'] = "Tesla - BH Commerce <tesla@bhcommerce.com.br>";
        $email['assunto'] = ("Email enviado pelo formulário de Fale Conosco do Site - Tesla - BH Commerce");
        $email['corpo'] = ('<html><head><title>Email enviado pelo formulário de Fale Conosco do Site - Tesla - BH Commerce</title></head><body><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td width="250" style="width: 250px; text-align: center;"><img src="https://tesla.bhcommerce.com.br/img/logo.png" width="200"></td><td>Olá, foi enviado um novo email a partir do formulário de fale conosco do site. Veja os dados enviados abaixo:<br><br><b>Nome:</b> '.$_REQUEST['nome'].'<br><b>Email:</b> '.$_REQUEST['email'].'<br><b>Telefone:</b> '.$_REQUEST['telefone'].'<br><b>Mensagem:</b> '.nl2br($_REQUEST['mensagem']).'<br><br>Atenciosamente,<br><br>Equipe <a href="https://tesla.bhcommerce.com.br/">Tesla - BH Commerce</a><br><hr noshade><center>Email Desenvolvido Pela <a href="https://www.bhcommerce.com.br/">BH Commerce</a></center><hr noshade></td></tr></table></body></html>');
        $email['cabecalho'] = "Content-Type: text/html; charset=iso-8859-1\n";
        $email['cabecalho'] .= "From: ".$_REQUEST['nome']." <".$_REQUEST['email'].">\nReply-To: Tesla - BH Commerce <tesla@bhcommerce.com.br>";
        mail(utf8_decode($email['nome']), utf8_decode($email['assunto']), utf8_decode($email['corpo']), utf8_decode($email['cabecalho']));
        echo "1";
        break;
    default:
        echo "0|-|Não foi encontrada a ação pesquisada!";
        break;
}
?>

var formulario = document.querySelector('.formulario');

var maioresInformacoesY = document.querySelector('.maioresInformacoesY');

var maioresInformacoesX = document.querySelector('.maioresInformacoesX');

var maioresInformacoesZ = document.querySelector('.maioresInformacoesZ');

function aparecerFormulario(){
    formulario.style.left = "15%";
}

function desaparecerFormulario(){
    formulario.style.left = "-100%";
}

function vejaMaioresInformacoesY(){
    maioresInformacoesY.style.left = "15%";    
}

function desaparecerMaioresInformacoesY(){
    maioresInformacoesY.style.left = "-100%";
}

function vejaMaioresInformacoesX(){
    maioresInformacoesX.style.left = "15%";    
}

function desaparecerMaioresInformacoesX(){
    maioresInformacoesX.style.left = "-100%";
}

function vejaMaioresInformacoesZ(){
    maioresInformacoesZ.style.left = "15%";    
}

function desaparecerMaioresInformacoesZ(){
    maioresInformacoesZ.style.left = "-100%";
}

function mascara(src, mask, evt){
    var i = src.value.length;
    var saida = mask.substring(i,i+1);
    var ascii = evt.keyCode;
    if(i < mask.length || ascii == 8 || ascii == 9){
        if(document.all){
            var evt = event.keyCode;
        }
        else{
            var evt = evt.which;
        }
        if (saida == "A")
        {
            if ((ascii >=97) && (ascii <= 122))
                evt.keyCode -= 32;
            else
                evt.keyCode = 0;
        }
        else if (saida == "0")
        {
            if ((ascii >= 48) && (ascii <= 57))
                return;
            else
                evt.keyCode = 0;
        }
        else if (saida == "#")
            return;
        else if(ascii != 8)
        {
            src.value += saida;
            i += 1;
            saida = mask.substring(i,i+1);
            if (saida == "A")
            {
                if ((ascii >=97) && (ascii <= 122))
                    evt.keyCode -= 32;
                else
                    evt.keyCode = 0;
            }
            else if (saida == "0")
            {
                if ((ascii >= 48) && (ascii <= 57))
                    return;
                else
                    evt.keyCode = 0;
            }
            else
                return;
        }
    }
    else
        return false;
}

$("#form").submit(function(evt){
    evt.preventDefault();
    var formData = new FormData($(this)[0]);
    $.ajax({
        url: 'ajax.php?acao=enviarContato',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
            }
            else if (vet[0] == 1) {
                $("#nome").val('');
                $("#email").val('');
                $("#telefone").val('');
                $("#mensagem").val('');
                alert('Email Enviado com sucesso! Aguarde o nosso retorno por email ou telefone!');
            }
        },
    });
    return false;
});
$("#salvarContato").submit(function(evt){
    evt.preventDefault();
    var formData = new FormData($(this)[0]);
    $.ajax({
        url: 'ajax.php?acao=enviarContato',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
            }
            else if (vet[0] == 1) {
                $("#nomeContato").val('');
                $("#emailContato").val('');
                $("#telefoneContato").val('');
                $("#mensagemContato").val('');
                alert('Email Enviado com sucesso! Aguarde o nosso retorno por email ou telefone!');
            }
        },
    });
    return false;
});
Projeto Tesla

------------//--------------

Projeto Tesla, feito utilizando as tecnologias HTML, CSS, JavaScript, PHP e Ajax.

------------//-------------

É só você baixar o projeto, executar o arquivo tesla.zip e extrair para uma pasta qualquer do computador. Aí é só executar o arquivo index.html para ver o projeto.

------------//-------------

Ou acessar o seguinte endereço: https://tesla.bhcommerce.com.br 